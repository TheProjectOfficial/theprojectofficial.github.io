fetch("https://theprojectofficial.github.io/datacenter/api/status.json")
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                // Dynamically update the status content with fetched data
                const statusElement = document.getElementById("status");

                // Optionally, you can format the data for a better display
                statusElement.innerHTML = `
                    <strong>Status:</strong> ${data.status || 'No status found'}<br>
                    <strong>Message:</strong> ${data.message || 'No message available.'}
                `;

                // Change the title once data is loaded
                document.getElementById("title").textContent = "Data Fetched Successfully!";
            })
            .catch(error => {
                console.error("Error fetching data:", error);
                document.getElementById("status").textContent = "Error fetching data.";
            });